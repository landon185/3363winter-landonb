## Database

Database name:
Table 1(Parent):
Table 2(Child):
Primary key(Table 1):
Foreign key(Table 2):

## Data

Rows in Table 1:
Rows in Table 2:

## JOIN querry I ran

'''sql
--paste your JOIN querry here
