# Lab 06 — PHP Web Security & Sessions (Secure Notes)
**Student Name:** Landon Ball
**Date:** Febuary 10th 2026
## 1) What I built (1–2 sentences)
I built a secure login to a dashboard. It has an admin page resticted to users with admin status.
## 2) How to run my lab
**Database name:** `lab06_yourfirstname'
**Start page URL:**
Steps:
1. Start XAMPP (Apache + MySQL)
2. Open phpMyAdmin and create my database
3. Run the Lab06 SQL to create tables: `users`, `notes`
4. Update `app/db.php` with my DB name
5. Open the start page URL above
## 3) Security features checklist:
## 4) Test Results (PASS/FAIL)
- Register works: Pass
- Login works (correct password): Pass
- Login fails (wrong password): Pass
- Dashboard redirects when logged out: Pass
- Create note works: Pass
- XSS test does NOT run (`<script>alert('xss')</script>`): Pass
- Admin page (user gets 403): Pass
- Admin page (admin can view): Pass
- Session timeout works: Pass

## 5) Reflection: what I have learned from Lab 06 (3-5 sentences)
This lab was very hands on and allowed for us to see how much backend work there is for such a simple protected dashboard. It really puts into perspective just how much work goes into certain apps and even if they look simplistic there is lots going on. It was really cool having control on who gets admin permission. 