<?php
require_once __DIR__ . "/../config/db.php";
require_once __DIR__ . "/../includes/functions.php";
$id = get_int_or_null($_GET["id"] ?? null);
if (!$id) {
 redirect("index.php?msg=error");
}
// Load student for confirmation display
$sql = "SELECT student_id, full_name, email, program
 FROM students
 WHERE student_id = :id";
$stmt = $pdo->prepare($sql);
$stmt->execute([":id" => $id]);
$student = $stmt->fetch();
if (!$student) {
 redirect("index.php?msg=error");
}
if ($_SERVER["REQUEST_METHOD"] === "POST") {
 // Perform delete
 $sql = "DELETE FROM students WHERE student_id = :id";
 $stmt = $pdo->prepare($sql);
 $stmt->execute([":id" => $id]);
 redirect("index.php?msg=deleted");
}
?>
<?php require_once __DIR__ . "/../includes/header.php"; ?>
<h2>Delete Student</h2>
<div class="error">
 <p><strong>Are you sure you want to delete this student?</strong></p>
 <ul>
 <li><strong>Name:</strong> <?= e($student["full_name"]) ?></li>
 <li><strong>Email:</strong> <?= e($student["email"]) ?></li>
 <li><strong>Program:</strong> <?= e($student["program"]) ?></li>
 </ul>
</div>
<form method="post" action="delete.php?id=<?= (int)$id ?>">
 <div class="form-actions">
 <button class="btn danger" type="submit">Yes, Delete</button>
 <a class="btn" href="index.php">Cancel</a>
 </div>
</form>
<?php require_once __DIR__ . "/../includes/footer.php"; ?>