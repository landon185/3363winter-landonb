<?php
declare(strict_types=1);
require_once __DIR__ . "/../app/security.php";
security_headers();
?>
<!doctype html>
<html lang="en">
<head>
 <meta charset="utf-8">
 <title>Lab 06 - Secure Notes</title>
 <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="wrapper">
<h1>Lab 06 - Secure Notes</h1>
 <ul>
 <li><a href="register.php">Register</a></li>
 <li><a href="login.php">Login</a></li>
 <li><a href="dashboard.php">Dashboard (protected)</a></li>
 <li><a href="admin.php">Admin page (admin only)</a></li>
 </ul>
 </div> 
</body>
</html>