<?php
?>

 <!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="UTF-8" />
 <meta name="viewport" content="width=device-width, initial-scale=1.0" />
 <title>lab04_landon - MySQL Fundamentals Documentation</title>
 <style>
 body { font-family: Arial, sans-serif; margin: 24px; line-height: 1.5; }
 h1, h2, h3 { margin-bottom: 6px; }
 .meta { margin-top: 0; color: #333; }
code { background: #f3f3f3; padding: 2px 6px; border-radius: 4px; }
 pre { background: #f3f3f3; padding: 12px; border-radius: 6px; overflow-x: auto; }
 ul { margin-top: 6px; }
 .section { margin-top: 18px; }
 .note { color: #444; font-size: 0.95em; }
 table { border-collapse: collapse; margin-top: 8px; width: 100%; max-width: 720px; }
 th, td { border: 1px solid #ccc; padding: 8px; text-align: left; }
 th { background: #f6f6f6; }
 </style>
</head>
<body>
 <h1>Lab 04: MySQL Fundamentals (phpMyAdmin)</h1>
 <p class="meta">
 <strong>Name:</strong>
  Landon Ball
 <br>
 <strong>Date:</strong>
 2026-02-01
 </p>
 <div class="section">
 <h2>Database</h2>
 <p>
<strong>Instructor demo database name:</strong>
 <code>lab04_demo</code>
 <br>
 <span class="note">
 Students: your database name must follow the course rule below.
 </span>
 </p>
 <p>
 <strong>Student database naming rule:</strong>
 <code>lab04_landon</code>
 </p>
 </div>
 <div class="section">
 <h2>Tables and Purpose</h2>
 <ul>
 <li>
 <strong>customers</strong>
 — Stores customer information (one row per customer).
 </li>
 <li>
 <strong>orders</strong>
 — Stores order records (one row per order) and links each order to a customer using
<code>customer_id</code>.
 </li>
 </ul>
 </div>
 <div class="section">
    <h2>Table Fields (Columns)</h2>
 <h3>customers</h3>
 <ul>
 <li><code>customer_id</code> — INT (PRIMARY KEY, AUTO_INCREMENT)</li>
 <li><code>first_name</code> — VARCHAR(50)</li>
 <li><code>last_name</code> — VARCHAR(50)</li>
 <li><code>email</code> — VARCHAR(100)</li>
 </ul>
 <h3>orders</h3>
 <ul>
 <li><code>order_id</code> — INT (PRIMARY KEY, AUTO_INCREMENT)</li>
 <li><code>customer_id</code> — INT (FOREIGN KEY → <code>customers.customer_id</code>)</li>
 <li><code>order_date</code> — DATE</li>
 <li><code>total_amount</code> — DECIMAL(8,2)</li>
 <li><code>status</code> — VARCHAR(20)</li>
 </ul>
  <pclass="note">
 Relationship: <code>orders.customer_id</code> connects each order to a customer in
<code>customers</code>.
 </p>
 </div>
 <div class="section">
 <h2>Sample Data Inserted (at least 3 rows per table)</h2>
 <h3>Customers (example)</h3>
 <table>
 <thead>
 <tr>
 <th>Customer</th>
 <th>Email</th>
 </tr>
 </thead>
 <tbody>
 <!-- STUDENT TODO: Replace these example rows with YOUR real sample data (3+ rows). -->
 <tr><td>Cory Barker</td><td>coryb@example.com</td></tr>
 <tr><td>Bryasha Johnson</td><td>bryashaj@example.com</td></tr>
 <tr><td>Marshall Drake</td><td>marshalld@example.com</td></tr>
 </tbody>
 </table>
 <h3>Orders (example)</h3>
 <p class="note">
 These orders should use valid <code>customer_id</code> values that exist in your <code>customers</code>
table.
 </p>
 <table>
 <thead>
 <tr>
 <th>Order Date</th>
 <th>Total Amount</th>
 <th>Status</th>
 </tr>
 </thead>
 <tbody>
  <tr><td>2026-02-01</td><td>64.99</td><td>paid</td></tr>
 <tr><td>2026-02-01</td><td>39.99</td><td>pending</td></tr>
 <tr><td>2026-02-01</td><td>72.99</td><td>pending</td></tr>
 </tbody>
 </table>
 </div>
 <div class="section">
 <h2>Sample SQL Queries (run in phpMyAdmin → SQL tab)</h2>
 <p class="note">
 Your screenshots should include at least one JOIN query showing the relationship between your two tables.
 </p>
 <pre><code>SELECT * FROM customers;</code></pre>
 <pre><code>SELECT * FROM orders
ORDER BY total_amount DESC;</code></pre>
 <pre><code>SELECT c.customer_id, c.first_name, c.last_name, c.email,
 o.order_id, o.order_date, o.total_amount, o.status
FROM customers c 
JOIN orders o ON c.customer_id = o.customer_id
ORDER BY o.order_date DESC;</code></pre>
 </div>
 <div class="section">
 <h2>Export Confirmation</h2>
 <p>
I exported my database from phpMyAdmin as:
 <code>lab04_landon.sql</code>
 <br>
 and saved it in:
 <code>C:\xampp\htdocs\winter3363\lab04\lab04_landon.sql</code>
 </p>
 <p class="note">
 Example (instructor demo): database name <code>lab04_demo</code> could export to
<code>lab04_demo.sql</code>.
 </p>
 </div> 
 </body>
</html> 