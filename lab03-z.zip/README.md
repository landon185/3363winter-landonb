# Lab 03-PHP Forms + Validation
 Make a php form that can only be accessed by verrified users. As well as clearing and destroyiny the session using cookies.

 ## Features list
 - server side validation
 - protected page
 - PHP sessions to track login state
 - Clears and destroys session when logging out

## How to run (XAMPP)
1. Start **Apache** in XAMPP.
2. Put this folder at:
   `C:\xampp\htdocs\3363winter\lab03\`
3. Open in browser:
   http://localhost/3363winter/login.php

## Demo credentials
- Username: student
- Password: Lab03!

## Concepts
- POST form handling
- Required checks on the server
- Sessions for login state
- Escaping output with htmlspecialchars()

## Reflextion
Overall this project did a good job explaining different asspects of sessions and how to properly use them. I had made a few syntax errors and completly missed a chunck of code in the login pages code but the error messages were quite helpful in identifying where the error was and how to fix it. On the log out page though it is not working properly and ive tried a lot of troubleshooting and its not helping. I am looking forward to my feedback so i can do much better going forward since iI am not very proud of what im submitting.